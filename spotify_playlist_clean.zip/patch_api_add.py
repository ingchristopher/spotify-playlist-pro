from pathlib import Path
import re

p = Path("app.py")
text = p.read_text()

# Agregar scope correcto
text = text.replace(
'SCOPES = "playlist-modify-public playlist-modify-private"',
'SCOPES = "playlist-modify-public playlist-modify-private playlist-read-private"'
)

# Reemplazar bloque viejo de AppleScript
pattern = r'''
                links = "\\\\n"\.join\(selected\)

.*?

                self.msg\("Canciones pegadas\."\)
'''

replacement = r'''
                try:

                    track_uris = []

                    for link in selected:

                        m2 = re.search(r"track/([A-Za-z0-9]+)", link)

                        if m2:
                            track_uris.append(
                                f"spotify:track:{m2.group(1)}"
                            )

                    if track_uris:

                        client.playlist_add_items(
                            playlist_id,
                            track_uris
                        )

                        self.msg(f"Canciones agregadas API: {len(track_uris)}")

                        self.web.reload()

                    else:

                        self.msg("No encontré track URIs.")

                except Exception as e:

                    self.msg("ERROR agregando canciones:")
                    self.msg(str(e))
'''

text = re.sub(pattern, replacement, text, flags=re.DOTALL)

p.write_text(text)

print("PATCH API ADD aplicado ✅")
