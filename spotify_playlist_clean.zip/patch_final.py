from pathlib import Path
import re

p = Path("app.py")
text = p.read_text()

# FIX nombres por coma
old = '''
        ideas = read(FILES["ideas"])

        if not ideas:
            return "Playlist Automática"

        used = set(read(FILES["used_names"]))

        available = [x for x in ideas if x not in used]
'''

new = '''
        raw = FILES["ideas"].read_text(encoding="utf-8")

        ideas = []

        for part in re.split(r"[\\n,]+", raw):
            part = part.strip()
            if part:
                ideas.append(part)

        if not ideas:
            return "Playlist Automática"

        used = set(read(FILES["used_names"]))

        available = [x for x in ideas if x not in used]
'''

text = text.replace(old, new)

# NUEVO método pegar canciones
pattern = r'''
                applescript = f'''
                set the clipboard to "\{links\}"

                tell application "System Events"
                    keystroke "v" using command down
                    delay 1
                    key code 36
                end tell
                '''

                subprocess.run\(\[
                    "osascript",
                    "-e",
                    applescript
                \]\)

                self.msg\("Canciones pegadas."\)
'''

replacement = r'''
                js_open_add = """
                (async function() {

                    let buttons = [...document.querySelectorAll('button')];

                    for (let b of buttons) {

                        let txt = b.innerText || "";

                        if (
                            txt.includes("Add songs") ||
                            txt.includes("Agregar canciones") ||
                            txt.includes("Find more") ||
                            txt.includes("Añadir")
                        ) {
                            b.click();
                            return "OPENED_ADD";
                        }
                    }

                    return "BUTTON_NOT_FOUND";

                })();
                """

                self.web.page().runJavaScript(js_open_add)

                def do_paste():

                    applescript = f'''
                    set the clipboard to "{links}"

                    tell application "System Events"

                        delay 1

                        keystroke "l" using command down
                        delay 1

                        keystroke "v" using command down
                        delay 1

                        key code 36

                    end tell
                    '''

                    subprocess.run([
                        "osascript",
                        "-e",
                        applescript
                    ])

                    self.msg("Canciones enviadas al buscador Spotify.")

                QTimer.singleShot(2500, do_paste)
'''

text = re.sub(pattern, replacement, text, flags=re.DOTALL)

p.write_text(text)

print("PATCH FINAL aplicado ✅")
